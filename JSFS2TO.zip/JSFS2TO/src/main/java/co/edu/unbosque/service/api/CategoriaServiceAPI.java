package co.edu.unbosque.service.api;

import co.edu.unbosque.utils.GenericServiceAPI;
import co.edu.unbosque.entity.Categoria;

public interface CategoriaServiceAPI extends GenericServiceAPI<Categoria, Long>  {
  
}
