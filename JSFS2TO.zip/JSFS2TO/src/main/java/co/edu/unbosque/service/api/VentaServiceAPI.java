package co.edu.unbosque.service.api;

import co.edu.unbosque.utils.GenericServiceAPI;
import co.edu.unbosque.entity.Venta;
 
public interface VentaServiceAPI extends GenericServiceAPI<Venta, Long>  {
	Venta update(Venta Venta);

}
