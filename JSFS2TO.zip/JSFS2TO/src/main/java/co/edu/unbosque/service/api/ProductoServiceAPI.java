package co.edu.unbosque.service.api;

import co.edu.unbosque.utils.GenericServiceAPI;
import co.edu.unbosque.entity.Producto;

 
public interface ProductoServiceAPI extends GenericServiceAPI<Producto, Long>  {

  
}
