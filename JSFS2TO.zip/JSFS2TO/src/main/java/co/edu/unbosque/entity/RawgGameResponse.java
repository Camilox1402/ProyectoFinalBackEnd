package co.edu.unbosque.entity;

import java.util.List;

import lombok.Data;
@Data
public class RawgGameResponse {
	 private List<RawgGame> results;
}
