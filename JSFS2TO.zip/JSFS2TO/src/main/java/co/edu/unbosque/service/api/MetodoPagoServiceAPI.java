package co.edu.unbosque.service.api;

import co.edu.unbosque.utils.GenericServiceAPI;
import co.edu.unbosque.entity.MetodoPago;

 
public interface MetodoPagoServiceAPI extends GenericServiceAPI<MetodoPago, Long>  {
  
}
