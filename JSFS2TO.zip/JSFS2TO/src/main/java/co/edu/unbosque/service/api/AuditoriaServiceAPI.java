package co.edu.unbosque.service.api;

import co.edu.unbosque.utils.GenericServiceAPI;
import co.edu.unbosque.entity.Auditoria;

 
public interface AuditoriaServiceAPI extends GenericServiceAPI<Auditoria, Long>  {
  
}
