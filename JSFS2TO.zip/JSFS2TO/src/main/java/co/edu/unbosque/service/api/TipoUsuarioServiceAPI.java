package co.edu.unbosque.service.api;

import co.edu.unbosque.utils.GenericServiceAPI;
import co.edu.unbosque.entity.TipoUsuario;

 
public interface TipoUsuarioServiceAPI extends GenericServiceAPI<TipoUsuario, Long>  {
  
}
