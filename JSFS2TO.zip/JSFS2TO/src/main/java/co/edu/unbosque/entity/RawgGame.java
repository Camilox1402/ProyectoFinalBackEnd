package co.edu.unbosque.entity;

import lombok.Data;

@Data
public class RawgGame {
    private String name;
    private String description_raw; 
    private String background_image; 
    private String slug;  

    
}
